package com.example.troy.swoleaf;

import com.android.volley.toolbox.Volley;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.CalendarView;
import android.widget.ExpandableListView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.ExpandableListView.OnGroupCollapseListener;
import android.widget.ExpandableListView.OnGroupExpandListener;
import android.widget.PopupWindow;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.*;


public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, OnChildClickListener {

    private static final String TAG = "ScheduleActivity";
    private static final String URL_FOR_SCHEDULE = "http://cop4331.hosted.nfoservers.com/schedule.php";
    SharedPreferences sp;
    ExpandableListAdapter listAdapter;
    ExpandableListView expListView;
    List<String> listDataHeader;
    HashMap<String, List<String>> listDataChild;
    JSONArray data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // String UserID = sp.getString("id","0");



        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        expListView = (ExpandableListView) findViewById(R.id.dailyView1);
        populateList();

        listAdapter = new ExpandableListAdapter(this, listDataHeader, listDataChild);
        expListView.setAdapter(listAdapter);
        expListView.setOnChildClickListener(this);

    }

    @Override
    public boolean onChildClick(ExpandableListView parent, View v,
                                int groupPosition, int childPosition, long id) {
      // Toast.makeText(getApplicationContext(), groupPosition+"Clicked", Toast.LENGTH_LONG).show();
        try {
            startActivity(new Intent(MainActivity.this, Pop.class));


            int c = 0;

            if(groupPosition == 0)
                Toast.makeText(getApplicationContext(), data.getJSONObject(childPosition).getString("wdescription")+"", Toast.LENGTH_LONG).show();
            else if(groupPosition == 1)
            {
                for(int i = 0; i < data.length(); i++)
                    if(data.getJSONObject(i).getInt("weekday") == 1) {
                        c = i;
                        break;
                    }
                Toast.makeText(getApplicationContext(), data.getJSONObject(childPosition + c).getString("wdescription")+"", Toast.LENGTH_LONG).show();
            }
            else if(groupPosition == 2)
            {
                for(int i = 0; i < data.length(); i++)
                    if(data.getJSONObject(i).getInt("weekday") == 2) {
                        c = i;
                        break;
                    }
                Toast.makeText(getApplicationContext(), data.getJSONObject(childPosition + c).getString("wdescription")+"", Toast.LENGTH_LONG).show();
            }
            else if(groupPosition == 3)
            {
                for(int i = 0; i < data.length(); i++)
                    if(data.getJSONObject(i).getInt("weekday") == 3) {
                        c = i;
                        break;
                    }
                Toast.makeText(getApplicationContext(), data.getJSONObject(childPosition + c).getString("wdescription")+"", Toast.LENGTH_LONG).show();
            }
            else if(groupPosition == 4)
            {
                for(int i = 0; i < data.length(); i++)
                    if(data.getJSONObject(i).getInt("weekday") == 4) {
                        c = i;
                        break;
                    }
                Toast.makeText(getApplicationContext(), data.getJSONObject(childPosition + c).getString("wdescription")+"", Toast.LENGTH_LONG).show();
            }
            else if(groupPosition == 5)
            {
                for(int i = 0; i < data.length(); i++)
                    if(data.getJSONObject(i).getInt("weekday") == 5) {
                        c = i;
                        break;
                    }
                Toast.makeText(getApplicationContext(), data.getJSONObject(childPosition + c).getString("wdescription")+"", Toast.LENGTH_LONG).show();
            }
            else if(groupPosition == 6)
            {
                for(int i = 0; i < data.length(); i++)
                    if(data.getJSONObject(i).getInt("weekday") == 6) {
                        c = i;
                        break;
                    }
                Toast.makeText(getApplicationContext(), data.getJSONObject(childPosition + c).getString("wdescription")+"", Toast.LENGTH_LONG).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        /*
        if(childPosition == 0)
        {
            Intent wIntent = new Intent(
                    MainActivity.this,
                    workouts.class);

            startActivity(wIntent);
        }
        */
        return true;
    }
    //if there is no data in a day, fix crashing error
    public void populateList()
    {
        listDataHeader = new ArrayList<String>();
        listDataChild = new HashMap<String, List<String>>();

        listDataHeader.add("Monday");
        listDataHeader.add("Tuesday");
        listDataHeader.add("Wednesday");
        listDataHeader.add("Thursday");
        listDataHeader.add("Friday");
        listDataHeader.add("Saturday");
        listDataHeader.add("Sunday");
        /*
        List<String> monday = new ArrayList<String>();
        monday.add("Biceps");
        monday.add("Triceps");
        */
        final List<String> monday = new ArrayList<String>();
       // monday.add("++Add Workout++");
        final List<String> tuesday = new ArrayList<String>();
       // tuesday.add("++Add Workout++");
        final List<String> wednesday = new ArrayList<String>();
       // wednesday.add("++Add Workout++");
        final List<String> thursday = new ArrayList<String>();
      //  thursday.add("++Add Workout++");
        final List<String> friday = new ArrayList<String>();
      //  friday.add("++Add Workout++");
        final List<String> saturday = new ArrayList<String>();
      //  saturday.add("++Add Workout++");
        final List<String> sunday = new ArrayList<String>();
      //  sunday.add("++Add Workout++");


        String cancel_req_tag = "schedule";
        StringRequest strReq = new StringRequest(Request.Method.POST,
                URL_FOR_SCHEDULE, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                try {
                    JSONArray jObj = new JSONArray(response);
                    boolean error = jObj.getJSONObject(0).getBoolean("error");

                    if (!error)
                    {
                        data = jObj;
                        for(int i = 0; i < jObj.length(); i++)
                        {
                            Toast.makeText(getBaseContext(), " " + jObj.getJSONObject(i),
                                    Toast.LENGTH_LONG).show();
                            if(jObj.getJSONObject(i).getInt("weekday") == 0)
                            {
                                if(jObj.getJSONObject(i).getInt("weight") == 0)
                                    monday.add("" + jObj.getJSONObject(i).getString("wname") + ":  " + jObj.getJSONObject(i).getString("reps") + " reps");
                                else
                                    monday.add("" + jObj.getJSONObject(i).getString("wname") + ":  "+ jObj.getJSONObject(i).getString("reps") + " reps, " + jObj.getJSONObject(i).getInt("weight") + "lbs");
                            }
                            else if(jObj.getJSONObject(i).getInt("weekday") == 1)
                            {
                                tuesday.add("" + jObj.getJSONObject(i).getString("wname"));
                            }
                            else if(jObj.getJSONObject(i).getInt("weekday") == 2)
                            {
                                wednesday.add("" + jObj.getJSONObject(i).getString("wname"));
                            }
                            else if(jObj.getJSONObject(i).getInt("weekday") == 3)
                            {
                                thursday.add("" + jObj.getJSONObject(i).getString("wname"));
                            }
                            else if(jObj.getJSONObject(i).getInt("weekday") == 4)
                            {
                                friday.add("" + jObj.getJSONObject(i).getString("wname"));
                            }
                            else if(jObj.getJSONObject(i).getInt("weekday") == 5)
                            {
                                saturday.add("" + jObj.getJSONObject(i).getString("wname"));
                            }
                            else if(jObj.getJSONObject(i).getInt("weekday") == 6)
                            {
                                sunday.add("" + jObj.getJSONObject(i).getString("wname"));
                            }
                        }

                        tuesday.add(" ");
                        wednesday.add(" ");
                        thursday.add(" ");
                        friday.add(" ");
                        saturday.add(" ");
                        sunday.add(" ");
                        tuesday.add(". ");
                        wednesday.add(". ");
                        thursday.add(" .");
                        friday.add(" .");
                        saturday.add(". ");
                        sunday.add(" .");

                        listDataChild.put(listDataHeader.get(0), monday);
                        listDataChild.put(listDataHeader.get(1), tuesday);
                        listDataChild.put(listDataHeader.get(2), wednesday);
                        listDataChild.put(listDataHeader.get(3), thursday);
                        listDataChild.put(listDataHeader.get(4), friday);
                        listDataChild.put(listDataHeader.get(5), saturday);
                        listDataChild.put(listDataHeader.get(6), sunday);
                    }
                    else
                    {

                        String errorMsg = jObj.getJSONObject(0).getString("error_msg");
                        Toast.makeText(getApplicationContext(),
                                errorMsg, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e)
                {
                    Toast.makeText(getBaseContext(), "FUCK YOU",
                            Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams()
            {
                // Posting params to login url
                Map<String, String> params = new HashMap<String, String>();
                params.put("userid", "1149198424");
                params.put("password", "xd");
                return params;
            }
        };
        // Adding request to request queue
        AppSingleton.getInstance(getApplicationContext()).addToRequestQueue(strReq,cancel_req_tag);

    }





    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_schedule) {
            // action
        } else if (id == R.id.nav_workouts) {

        } else if (id == R.id.nav_routines) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
