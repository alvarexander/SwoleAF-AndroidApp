package com.example.troy.swoleaf;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.TextView;

/**
 * Created by Troy on 4/29/2018.
 */

public class Pop extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.popwindow);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;
        getWindow().setLayout((int)(width * 0.8),(int)(height * 0.6));

        TextView wDescriptionView = (TextView)findViewById(R.id.descriptionView);
        TextView wNameView = (TextView)findViewById(R.id.nameView);
        TextView wRepsView = (TextView)findViewById(R.id.repsView);
        TextView wWeightView = (TextView)findViewById(R.id.weightView);
        String desc, name, weight, reps;
        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if(extras == null) {
                desc= null;
            } else {
                name= extras.getString("WorkoutName");
                wNameView.setText(name);
                reps= extras.getString("WorkoutReps");
                wRepsView.setText(reps + " Reps");
                weight= extras.getString("WorkoutWeight");
                if(!weight.equals("0"))
                    wWeightView.setText(weight + " lbs");
                desc= extras.getString("WorkoutDescription");
                wDescriptionView.setText(desc);

            }
        } else {
            desc= (String) savedInstanceState.getSerializable("WorkoutDescription");
            wDescriptionView.setText(desc);
            name= (String) savedInstanceState.getSerializable("WorkoutName");
            wNameView.setText(name);
            reps= (String) savedInstanceState.getSerializable("WorkoutReps");
            wRepsView.setText(reps);
            weight= (String) savedInstanceState.getSerializable("WorkoutWeight");
            if(!weight.equals("0"))
                wWeightView.setText(weight + " lbs");
        }


    }
}
