package cop4600group9.swoleaf;


import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;
import android.app.ProgressDialog;
import android.util.Log;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class SignUpActivity extends AppCompatActivity
{


    private static final String TAG = "SignUpActivity";
    private static final String URL_FOR_REGISTRATION = "http://cop4331.hosted.nfoservers.com/register.php";
    ProgressDialog progressDialog;

    private EditText signupInputName, signupInputEmail, signupInputPassword, signupInputLName, signupuserName;
    private Button btnSignUp;
    private Button btnLinkLogin;

    protected void onCreate(Bundle savedInstanceState)
    {
        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_signup);


    // Progress dialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);

        // Input for the user to give us their information
        signupuserName = (EditText) findViewById(R.id.username);
        signupInputName = (EditText) findViewById(R.id.firstname);
        signupInputLName = (EditText) findViewById(R.id.lastname);
        signupInputEmail = (EditText) findViewById(R.id.email);
        signupInputPassword = (EditText) findViewById(R.id.password);
        btnSignUp = (Button) findViewById(R.id.email_sign_up_button);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitForm();
            }
        });

    }



    private void submitForm()
    {
        registerUser(signupuserName.getText().toString(),
                signupInputName.getText().toString(),
                signupInputLName.getText().toString(),
                signupInputEmail.getText().toString(),
                signupInputPassword.getText().toString());
    }

    // Redirect the user to the terms and conditions if they want to read them
    public void redirect(View v)
    {
        Intent viewIntent =
                new Intent("android.intent.action.VIEW", Uri.parse("http://cop4331.hosted.nfoservers.com/SwoleAF%20Terms%20and%20Conditions.pdf"));
        startActivity(viewIntent);

    }

    private void registerUser(final String username,final String firstname, final String lastname, final String email, final String password)
    {
        // Tag used to cancel the request
        String cancel_req_tag = "register";
       
        StringRequest strReq = new StringRequest(Request.Method.POST,
                URL_FOR_REGISTRATION, new Response.Listener<String>()
        {

            @Override
            public void onResponse(String response)
            {

                try
                {
                    // Obtain response object from PHP code
                    JSONObject jObj = new JSONObject(response);
                    boolean error = jObj.getBoolean("error");
                    // If the error boolean if not set to true in PHP, this indicates successful registration
                    if (!error)
                    {
                        // Indicate to the user that they successfully registered
                        Toast.makeText(getBaseContext(), "Registration Successful, Welcome!",
                                Toast.LENGTH_LONG).show();


                        // Launch login activity
                        Intent intent = new Intent(
                                SignUpActivity.this,
                                LoginActivity.class);
                        startActivity(intent);
                        finish();
                    }

                    else
                    {
                        // The error boolean was set to true and the registration failed in the PHP -
                        // database query, we let the user know with a toast message
                        String errorMsg = jObj.getString("error_msg");
                        Toast.makeText(getApplicationContext(),
                                errorMsg, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e)
                {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener()
        {

            @Override
            public void onErrorResponse(VolleyError error)
            {
                Log.e(TAG, "Registration Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();
                hideDialog();
            }
        }) {
            @Override
            protected Map<String, String> getParams()
            {
                // Posting params to register url
                Map<String, String> params = new HashMap<String, String>();
                params.put("username", username);
                params.put("firstname", firstname);
                params.put("lastname", lastname);
                params.put("email", email);
                params.put("password", password);
                return params;
            }
        };
        // Adding request to request queue
        AppSingleton.getInstance(getApplicationContext()).addToRequestQueue(strReq, cancel_req_tag);
    }

    private void showDialog()
    {
        if (!progressDialog.isShowing())
            progressDialog.show();
    }

    private void hideDialog()
    {
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }
}



