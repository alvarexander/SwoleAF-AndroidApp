package cop4600group9.swoleaf;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.content.Intent;
import android.app.ProgressDialog;
import android.util.Log;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;


/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity
{

    private static final String TAG = "LoginActivity";
    private static final String URL_FOR_LOGIN = "http://cop4331.hosted.nfoservers.com/login.php";
    ProgressDialog progressDialog;
    private EditText loginInputEmail, loginInputPassword;
    private Button btnlogin;
    private Button btnLinkSignup;
    private ImageView myLogo;
    Context context;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_login);
        myLogo = (ImageView)findViewById(R.id.icon);
        context = getApplicationContext();

        sp = getSharedPreferences("login",MODE_PRIVATE);

        if(sp.getBoolean("logged",false))
        {
            Intent myintent = new Intent(getApplicationContext(), RoutinesActivity.class);

            startActivity(myintent);

            finish();


        }


        loginInputEmail = (EditText) findViewById(R.id.email);
        loginInputPassword = (EditText) findViewById(R.id.password);
        btnlogin = (Button) findViewById(R.id.email_sign_in_button);

        // Progress dialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);


        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginUser(loginInputEmail.getText().toString(),
                        loginInputPassword.getText().toString());
            }
        });



    }
    public void redirect(View v)
    {
        Intent myIntent = new Intent(LoginActivity.this, SignUpActivity.class);
        LoginActivity.this.startActivity(myIntent);

    }


    private void loginUser( final String username, final String password)
    {

        String cancel_req_tag = "login";
        StringRequest strReq = new StringRequest(Request.Method.POST,
                URL_FOR_LOGIN, new Response.Listener<String>()
        {

            @Override
            public void onResponse(String response)
            {

                try {
                    JSONObject jObj = new JSONObject(response);

                    boolean error = jObj.getBoolean("error");
                    // The boolean object error gets set to false in PHP which indicates the database call -
                    // found the user attempting to login
                    if (!error)
                    {


                        sp.edit().putBoolean("logged",true).apply();

                        // Get the Username from the user's input
                        String user = jObj.getString("uname");
                        String id = jObj.getString("id");
                        Toast.makeText(getBaseContext(), "Login Sucessful!" + " " + "Welcome: " + user,
                                Toast.LENGTH_LONG).show();

                        sp.edit().putString("user",user).apply();


                        // Upon successful authentication - re-direct the user to the correct activity
                        Intent lintent = new Intent(getApplicationContext(), RoutinesActivity.class);

                        startActivity(lintent);

                        finish();

                    }
                    else
                    {
                        // If the error boolean is set to true in the PHP code, it means the user authentication -
                        // failed, obtain errors message to display from the JSON object encoded
                        String errorMsg = jObj.getString("error_msg");
                        Toast.makeText(getApplicationContext(),
                                errorMsg, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e)
                {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener()
        {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                Log.e(TAG, "Login Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();
                hideDialog();
            }
        }) {
            @Override
            protected Map<String, String> getParams()
            {
                // Posting params to login url
                Map<String, String> params = new HashMap<String, String>();
                params.put("username", username);
                params.put("password", password);
                return params;
            }
        };
        // Adding request to request queue
        AppSingleton.getInstance(getApplicationContext()).addToRequestQueue(strReq,cancel_req_tag);
    }

    private void showDialog()
    {
        if (!progressDialog.isShowing())
            progressDialog.show();
    }
    private void hideDialog()
    {
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }
}